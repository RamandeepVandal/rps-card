import { View, Text, Button , Pressable} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React, { useState } from 'react';

import HomeScreen from './components/Home';
import AIScreen from './components/AI';
import SettingScreen from './components/Setting';
import GameScreen from './components/Game';
import InstruScreen from './components/Instru';

import Estyles from './components/Style';

function Home({navigation}) {
  const [option, setOption] = useState('PvP');
  const data = [{ value: 'PvP' }, { value: 'PvE' }];
  return (
    <View style={{alignItems: 'center'}}>
      <Text style={Estyles.title}>Rock-Paper-Scissors</Text>
      <br></br>
      <Pressable style={Estyles.setting} onPress={() => navigation.navigate('Setting')}>
          <Text style={Estyles.settingText}>Setting</Text>
      </Pressable>
      <Button title="Instruction" onPress={() => navigation.navigate('Instru')}/>
      <View style={Estyles.container}>
        <Text style={Estyles.paragraph}>Select Game Mode: </Text>
        <HomeScreen data={data} onSelect={(value) => setOption(value)} />
        <br></br>
        <Text> You have selected: {option}</Text>
        <Button title="Select" onPress={() => {navigation.navigate('PvE')}}/>
      </View>
    </View>
  );
}

function AI({navigation}) {
  return (
    <View style={{alignItems: 'center'}}>
      <Text style={Estyles.title}>Rock-Paper-Scissors</Text>
      <br></br>
      <Pressable style={Estyles.setting} onPress={() => navigation.navigate('Setting')}>
          <Text style={Estyles.settingText}>Setting</Text>
      </Pressable>
      <Button title="Instruction" onPress={() => navigation.navigate('Instru')}/>
      <AIScreen></AIScreen>
      <Button title="Select" onPress={() => {navigation.navigate('')}}/>
      <br></br>
      <Button title="Home" onPress={() => navigation.navigate('Home')}/>
    </View>
  );
}

function Setting({navigation}) {
  return (
    <View style={{alignItems: 'center'}}>
      <SettingScreen></SettingScreen>
      <Button title="Home" onPress={() => navigation.navigate('Home')}/>
    </View>
  );
}

function Game({navigation}) {
  return (
    <View style={{alignItems: 'center'}}>
      <GameScreen></GameScreen>
      <Button title="Home" onPress={() => navigation.navigate('Home')}/>
    </View>
  );
}

function Instru({navigation}) {
  return (
    <View style={{alignItems: 'center'}}>
      <InstruScreen></InstruScreen>
      <Button title="Home" onPress={() => navigation.navigate('Home')}/>
    </View>
  );
}

const Stack = createNativeStackNavigator();


function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={Home}/>
        <Stack.Screen name="PvE" component={AI}/>
        <Stack.Screen name="Setting" component={Setting}/>
        <Stack.Screen name="PvP" component={Game}/>
        <Stack.Screen name="Instru" component={Instru}/>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;