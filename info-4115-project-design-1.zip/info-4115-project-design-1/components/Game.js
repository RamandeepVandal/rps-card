import React from "react";
import {SafeAreaView,Text} from "react-native";

const Game = (props) => {
  return (
    <SafeAreaView>
      <Text>Game Screen</Text>
    </SafeAreaView>
  );
};

export default Game;