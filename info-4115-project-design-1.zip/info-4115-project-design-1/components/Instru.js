import React from "react";
import {SafeAreaView,Text} from "react-native";

import Estyles from './Style';

const Instru = (props) => {
  return (
    <SafeAreaView>
      <Text style={Estyles.title}>Instructions</Text>
      <br></br>
      <Text>1. Each player will have 20 health. </Text>
      <Text>2. The game ends when one or more players’ health is lower than 1.</Text>
      <Text>3. Each player will get 10 random cards of rock-paper-scissors.</Text>
      <Text>4. If a player wins a round, the opponent takes 1 damage. </Text>
      <Text>5. If both players selected the same. The player with more cards wins. The opponent takes 1 damage.</Text>
      <br></br>
    </SafeAreaView>
  );
};

export default Instru;