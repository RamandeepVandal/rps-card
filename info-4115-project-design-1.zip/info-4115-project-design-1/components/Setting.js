import React, { useState } from 'react';
import {SafeAreaView,Text, View} from "react-native";
import Slider from '@react-native-community/slider';

import Estyles from './Style';

const Setting = (props) => {
  const [range, setRange] = useState('50%')
  const [range2, setRange2] = useState('50%')

  return (
    <SafeAreaView>
      <Text style={Estyles.title}>Setting Screen</Text>
      <br></br>
      <View style={{alignItems:'center'}}>
        <Text>Volume</Text>
        <Text>{range}</Text>
        <Slider 
          style={{width:250, height:50}}
          minimumValue={0}
          maximumValue={1}
          value={.5}
          onValueChange={value => setRange(parseInt(value*100)+"%")}
        />
        <Text>Brightness</Text>
        <Text>{range2}</Text>
        <Slider 
          style={{width:250, height:50}}
          minimumValue={0}
          maximumValue={1}
          value={.5}
          onValueChange={value => setRange2(parseInt(value*100)+"%")}
        />
      </View>
    </SafeAreaView>
  );
};

export default Setting;