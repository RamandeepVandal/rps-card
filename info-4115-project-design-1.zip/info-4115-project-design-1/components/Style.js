import {StyleSheet} from 'react-native'

const styles = StyleSheet.create({
    title:{
      textAlign: "center",
      textTransform: "uppercase",
      fontWeight: "bold",
      fontSize: 24,
    },
    option: {
      fontSize: 20,
      color: 'white',
      textAlign: 'center',
    },
    unselected: {
      backgroundColor: 'red',
      margin: 5,
      padding: 10,
    },
    selected: {
      backgroundColor: 'blue',
      margin: 6,
      padding: 15,
      borderRadius: 10,
    },
    paragraph: {
      margin: 24,
      fontSize: 18,
      fontWeight: 'bold',
      textAlign: 'center',
    },
    setting:{
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 12,
      paddingHorizontal: 32,
      borderRadius: 10,
      elevation: 3,
      backgroundColor: '#99ffff'
    },
    settingText:{
      fontSize: 16,
      lineHeight: 21,
      fontWeight: 'bold',
      letterSpacing: 0.25,
      color: 'white',
    }
});

export default styles;